﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NextNPC : MonoBehaviour {

	public GameObject dialogPanel;

	public void startDialog() { 
		
		dialogPanel.SetActive  (true);

	}

}
